
import React from 'react';

const UploadImage = ({ onFileUpload }) => {
  const handleFileChange = (event) => {
    if (event.target.files && event.target.files[0]) {
      onFileUpload(event.target.files[0]);
    }
  };

  return (
    <div className="mb-4">
      <label className="block text-sm font-medium text-gray-700">
        Upload Image:
      </label>
      <input
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
      />
    </div>
  );
};

export default UploadImage;
