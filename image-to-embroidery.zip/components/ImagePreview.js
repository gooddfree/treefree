
import React from 'react';

const ImagePreview = ({ file }) => {
  const imageUrl = URL.createObjectURL(file);

  return (
    <div className="mt-4">
      <h2 className="text-lg font-medium">Preview:</h2>
      <img
        src={imageUrl}
        alt="Uploaded Preview"
        className="w-64 h-64 object-contain border border-gray-300 rounded-lg"
      />
    </div>
  );
};

export default ImagePreview;
