
import React, { useState } from 'react';
import UploadImage from './components/UploadImage';
import ImagePreview from './components/ImagePreview';
import axios from 'axios';

const App = () => {
  const [uploadedFile, setUploadedFile] = useState(null);
  const [convertedFileUrl, setConvertedFileUrl] = useState(null);

  const handleFileUpload = (file) => {
    setUploadedFile(file);
    setConvertedFileUrl(null); // Reset any previous conversion
  };

  const handleConvert = async () => {
    if (!uploadedFile) {
      alert("Please upload an image first.");
      return;
    }

    const formData = new FormData();
    formData.append('file', uploadedFile);

    try {
      const response = await axios.post('https://api.example.com/convert', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      // Assume the response contains a URL to the converted file
      setConvertedFileUrl(response.data.fileUrl);
    } catch (error) {
      console.error("Error converting file:", error);
      alert("Failed to convert file. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center p-6">
      <h1 className="text-4xl font-bold mb-6">Image to Embroidery Converter</h1>
      <UploadImage onFileUpload={handleFileUpload} />
      {uploadedFile && <ImagePreview file={uploadedFile} />}
      <button
        onClick={handleConvert}
        className="mt-4 px-6 py-2 bg-indigo-600 text-white rounded-lg shadow hover:bg-indigo-700"
      >
        Convert to Embroidery
      </button>
      {convertedFileUrl && (
        <div className="mt-4">
          <a
            href={convertedFileUrl}
            download
            className="px-6 py-2 bg-green-600 text-white rounded-lg shadow hover:bg-green-700"
          >
            Download Embroidery File
          </a>
        </div>
      )}
    </div>
  );
};

export default App;
